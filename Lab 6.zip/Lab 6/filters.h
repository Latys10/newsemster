#ifndef FILTERS_H
#define FILTERS_H

#include "bmp.h"


Image filterGray(const Image& src);
Image filterNegative(const Image& src);
Image filterBlur(const Image& src);
Image filterSharpen(const Image& src);


Image filterSepia(const Image& src);
Image filterEdges(const Image& src);


Image filterBrightness(const Image& src, int percent, bool keepBlack);

#endif
