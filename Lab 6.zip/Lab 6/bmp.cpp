#include "bmp.h"

#include <fstream>
#include <iterator>

namespace {

uint16_t rd16(const uint8_t* p) {
    return uint16_t(p[0] | (p[1] << 8));
}

uint32_t rd32(const uint8_t* p) {
    return uint32_t(p[0]) | (uint32_t(p[1]) << 8) | (uint32_t(p[2]) << 16) | (uint32_t(p[3]) << 24);
}

void wr16(std::vector<uint8_t>& v, uint16_t x) {
    v.push_back(uint8_t(x & 0xFF));
    v.push_back(uint8_t(x >> 8));
}

void wr32(std::vector<uint8_t>& v, uint32_t x) {
    for (int i = 0; i < 4; ++i)
        v.push_back(uint8_t((x >> (8 * i)) & 0xFF));
}

}

bool loadBmp(const std::string& path, Image& img, std::string& err) {
    std::ifstream f(path, std::ios::binary);
    if (!f) {
        err = "Не удалось открыть файл";
        return false;
    }
    std::vector<uint8_t> d((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());

    if (d.size() < 54) {
        err = "Файл слишком маленький для BMP";
        return false;
    }

    if (d[0] != 'B' || d[1] != 'M') {
        err = "Нет сигнатуры 'BM'";
        return false;
    }
    uint32_t dataOffset = rd32(&d[10]);


    uint32_t headerSize = rd32(&d[14]);
    if (headerSize < 40) {
        err = "Поддерживается только BITMAPINFOHEADER и новее";
        return false;
    }
    int32_t w = int32_t(rd32(&d[18]));
    int32_t h = int32_t(rd32(&d[22]));
    uint16_t bpp = rd16(&d[28]);
    uint32_t compression = rd32(&d[30]);
    uint32_t colorsUsed = rd32(&d[46]);

    bool topDown = h < 0;
    if (topDown) h = -h;

    if (w <= 0 || h <= 0) {
        err = "Некорректные размеры";
        return false;
    }

    if (!(compression == 0 || (compression == 3 && bpp == 32))) {
        err = "Сжатые BMP не поддерживаются";
        return false;
    }
    if (bpp != 1 && bpp != 4 && bpp != 8 && bpp != 24 && bpp != 32) {
        err = "Неподдерживаемая глубина цвета: " + std::to_string(bpp);
        return false;
    }


    std::vector<uint8_t> palette;
    if (bpp <= 8) {
        uint32_t count = colorsUsed ? colorsUsed : (1u << bpp);
        size_t palPos = 14 + headerSize;
        if (palPos + size_t(count) * 4 > d.size()) {
            err = "Палитра выходит за пределы файла";
            return false;
        }
        palette.resize(size_t(count) * 3);
        for (uint32_t i = 0; i < count; ++i) {
            const uint8_t* e = &d[palPos + i * 4];
            palette[i * 3 + 0] = e[2];
            palette[i * 3 + 1] = e[1];
            palette[i * 3 + 2] = e[0];
        }
    }

    size_t rowSize = ((size_t(w) * bpp + 31) / 32) * 4;
    if (size_t(dataOffset) + rowSize * size_t(h) > d.size()) {
        err = "Пиксельные данные выходят за пределы файла";
        return false;
    }

    img.width = w;
    img.height = h;
    img.rgb.assign(size_t(w) * h * 3, 0);

    for (int fy = 0; fy < h; ++fy) {

        int y = topDown ? fy : (h - 1 - fy);
        const uint8_t* row = &d[dataOffset + size_t(fy) * rowSize];
        for (int x = 0; x < w; ++x) {
            uint8_t* dst = img.pixel(x, y);
            if (bpp == 24 || bpp == 32) {
                size_t bytes = bpp / 8;
                const uint8_t* s = row + size_t(x) * bytes;
                dst[0] = s[2];
                dst[1] = s[1];
                dst[2] = s[0];
            } else {
                unsigned idx;
                if (bpp == 8) {
                    idx = row[x];
                } else if (bpp == 4) {
                    uint8_t b = row[x / 2];
                    idx = (x % 2 == 0) ? (b >> 4) : (b & 0x0F);
                } else { // 1
                    idx = (row[x / 8] >> (7 - x % 8)) & 1;
                }
                if (idx * 3 + 2 >= palette.size()) idx = 0;
                dst[0] = palette[idx * 3 + 0];
                dst[1] = palette[idx * 3 + 1];
                dst[2] = palette[idx * 3 + 2];
            }
        }
    }
    return true;
}

bool saveBmp(const std::string& path, const Image& img, std::string& err) {
    if (img.empty()) {
        err = "Нет изображения";
        return false;
    }
    size_t rowSize = ((size_t(img.width) * 3 + 3) / 4) * 4;
    size_t dataSize = rowSize * img.height;
    uint32_t fileSize = uint32_t(54 + dataSize);

    std::vector<uint8_t> out;
    out.reserve(fileSize);


    out.push_back('B');
    out.push_back('M');
    wr32(out, fileSize);
    wr32(out, 0);
    wr32(out, 54);


    wr32(out, 40);
    wr32(out, uint32_t(img.width));
    wr32(out, uint32_t(img.height));
    wr16(out, 1);
    wr16(out, 24);
    wr32(out, 0);
    wr32(out, uint32_t(dataSize));
    wr32(out, 2835);
    wr32(out, 2835);
    wr32(out, 0);
    wr32(out, 0);

    // Пиксели
    for (int y = img.height - 1; y >= 0; --y) {
        size_t start = out.size();
        for (int x = 0; x < img.width; ++x) {
            const uint8_t* p = img.pixel(x, y);
            out.push_back(p[2]);
            out.push_back(p[1]);
            out.push_back(p[0]);
        }
        while (out.size() - start < rowSize)
            out.push_back(0);
    }

    std::ofstream f(path, std::ios::binary);
    if (!f) {
        err = "Не удалось создать файл";
        return false;
    }
    f.write(reinterpret_cast<const char*>(out.data()), std::streamsize(out.size()));
    if (!f) {
        err = "Ошибка записи";
        return false;
    }
    return true;
}
