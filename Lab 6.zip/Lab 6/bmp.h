#ifndef BMP_H
#define BMP_H

#include <cstdint>
#include <string>
#include <vector>


struct Image {
    int width = 0;
    int height = 0;
    std::vector<uint8_t> rgb;

    bool empty() const { return width <= 0 || height <= 0; }

    uint8_t* pixel(int x, int y) { return &rgb[(size_t(y) * width + x) * 3]; }
    const uint8_t* pixel(int x, int y) const { return &rgb[(size_t(y) * width + x) * 3]; }
};


bool loadBmp(const std::string& path, Image& img, std::string& err);

bool saveBmp(const std::string& path, const Image& img, std::string& err);

#endif
