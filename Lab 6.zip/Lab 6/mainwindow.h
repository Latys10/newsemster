#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <vector>
#include "bmp.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget* parent = nullptr);
    ~MainWindow() override;

private slots:
    void openFile();
    void saveFile();
    void applyGray();
    void applyNegative();
    void applyBlur();
    void applySharpen();
    void applySepia();
    void applyEdges();
    void applyBrightness();
    void undo();
    void redo();
    void resetImage();

private:

    void bind(const QString& name, void (MainWindow::*slot)());
    void setEnabledByName(const QString& name, bool on);

    void apply(const Image& result);
    void showImage();
    void updateUi();
    int strength() const;

    Ui::MainWindow* ui;
    Image m_original;
    Image m_current;
    std::vector<Image> m_undo;
    std::vector<Image> m_redo;
};

#endif
