#include "filters.h"

#include <algorithm>
#include <cmath>

// Чтобы после нескольких операций чёрный не выцветал и не терялся:
//  1) вычисления целочисленные
//  2) ядра нормированы
//  3) края обрабатываются повтором крайнего пикселя
//  4) результат ограничивается диапазоном 0..255

namespace {

inline uint8_t clamp255(int v) {
    return uint8_t(std::min(255, std::max(0, v)));
}

inline int clampInt(int v, int lo, int hi) {
    return std::min(hi, std::max(lo, v));
}

Image convolve3x3(const Image& src, const int k[9], int divisor) {
    Image dst;
    dst.width = src.width;
    dst.height = src.height;
    dst.rgb.resize(src.rgb.size());

    for (int y = 0; y < src.height; ++y) {
        for (int x = 0; x < src.width; ++x) {
            for (int c = 0; c < 3; ++c) {
                int sum = 0;
                for (int ky = -1; ky <= 1; ++ky) {
                    int yy = clampInt(y + ky, 0, src.height - 1);
                    for (int kx = -1; kx <= 1; ++kx) {
                        int xx = clampInt(x + kx, 0, src.width - 1);
                        sum += k[(ky + 1) * 3 + (kx + 1)] * src.pixel(xx, yy)[c];
                    }
                }
                int v = (sum <= 0) ? 0 : (sum + divisor / 2) / divisor;
                dst.pixel(x, y)[c] = clamp255(v);
            }
        }
    }
    return dst;
}

inline int luma(const uint8_t* p) {
    return (299 * p[0] + 587 * p[1] + 114 * p[2] + 500) / 1000;
}

} // namespace

Image filterGray(const Image& src) {
    Image dst = src;
    for (int y = 0; y < src.height; ++y) {
        for (int x = 0; x < src.width; ++x) {
            int g = luma(src.pixel(x, y));
            uint8_t* q = dst.pixel(x, y);
            q[0] = q[1] = q[2] = clamp255(g);
        }
    }
    return dst;
}

Image filterNegative(const Image& src) {
    Image dst = src;
    for (auto& v : dst.rgb)
        v = uint8_t(255 - v);
    return dst;
}

Image filterBlur(const Image& src) {
    static const int k[9] = {1, 2, 1,
                             2, 4, 2,
                             1, 2, 1};
    return convolve3x3(src, k, 16);
}

Image filterSharpen(const Image& src) {
    static const int k[9] = { 0, -1,  0,
                             -1,  5, -1,
                              0, -1,  0};
    return convolve3x3(src, k, 1);
}

Image filterSepia(const Image& src) {
    Image dst = src;
    for (int y = 0; y < src.height; ++y) {
        for (int x = 0; x < src.width; ++x) {
            const uint8_t* p = src.pixel(x, y);
            uint8_t* q = dst.pixel(x, y);
            q[0] = clamp255((393 * p[0] + 769 * p[1] + 189 * p[2] + 500) / 1000);
            q[1] = clamp255((349 * p[0] + 686 * p[1] + 168 * p[2] + 500) / 1000);
            q[2] = clamp255((272 * p[0] + 534 * p[1] + 131 * p[2] + 500) / 1000);
        }
    }
    return dst;
}

Image filterEdges(const Image& src) {
    Image dst = src;
    for (int y = 0; y < src.height; ++y) {
        for (int x = 0; x < src.width; ++x) {
            int l[3][3];
            for (int ky = -1; ky <= 1; ++ky)
                for (int kx = -1; kx <= 1; ++kx)
                    l[ky + 1][kx + 1] = luma(src.pixel(clampInt(x + kx, 0, src.width - 1),
                                                       clampInt(y + ky, 0, src.height - 1)));
            int gx = -l[0][0] + l[0][2] - 2 * l[1][0] + 2 * l[1][2] - l[2][0] + l[2][2];
            int gy = -l[0][0] - 2 * l[0][1] - l[0][2] + l[2][0] + 2 * l[2][1] + l[2][2];
            int m = int(std::lround(std::sqrt(double(gx * gx + gy * gy))));
            uint8_t* q = dst.pixel(x, y);
            q[0] = q[1] = q[2] = clamp255(m);
        }
    }
    return dst;
}

Image filterBrightness(const Image& src, int percent, bool keepBlack) {
    // Таблица на 256 значений
    uint8_t lut[256];
    for (int v = 0; v < 256; ++v) {
        if (keepBlack)
            lut[v] = clamp255((v * (100 + percent) + 50) / 100);
        else
            lut[v] = clamp255(v + int(std::lround(percent * 255 / 100.0)));
    }
    Image dst = src;
    for (auto& v : dst.rgb)
        v = lut[v];
    return dst;
}
