#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "filters.h"

#include <algorithm>

#include <QAbstractButton>
#include <QCheckBox>
#include <QFileDialog>
#include <QImage>
#include <QLabel>
#include <QMessageBox>
#include <QPixmap>
#include <QSlider>
#include <QSpinBox>

namespace {
const int kMaxHistory = 30;
}

MainWindow::MainWindow(QWidget* parent) : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);


    bind("btnOpen", &MainWindow::openFile);
    bind("btnSave", &MainWindow::saveFile);
    bind("btnGray", &MainWindow::applyGray);
    bind("btnNegative", &MainWindow::applyNegative);
    bind("btnBlur", &MainWindow::applyBlur);
    bind("btnSharpen", &MainWindow::applySharpen);
    bind("btnSepia", &MainWindow::applySepia);
    bind("btnEdges", &MainWindow::applyEdges);
    bind("btnApplyBrightness", &MainWindow::applyBrightness);
    bind("btnUndo", &MainWindow::undo);
    bind("btnRedo", &MainWindow::redo);
    bind("btnReset", &MainWindow::resetImage);

    if (auto* lbl = findChild<QLabel*>("lblImage")) {
        lbl->setAlignment(Qt::AlignCenter);
        lbl->setText("Откройте BMP файл");
    }
    updateUi();
}

MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::bind(const QString& name, void (MainWindow::*slot)()) {
    if (auto* b = findChild<QAbstractButton*>(name))
        connect(b, &QAbstractButton::clicked, this, slot);
}

void MainWindow::setEnabledByName(const QString& name, bool on) {
    if (auto* w = findChild<QWidget*>(name))
        w->setEnabled(on);
}

int MainWindow::strength() const {
    if (auto* s = findChild<QSpinBox*>("spinStrength"))
        return std::max(1, s->value());
    return 1;
}

void MainWindow::openFile() {
    QString path = QFileDialog::getOpenFileName(this, "Открыть BMP", QString(), "BMP (*.bmp)");
    if (path.isEmpty())
        return;

    Image img;
    std::string err;
    if (!loadBmp(path.toStdString(), img, err)) {
        QMessageBox::warning(this, "Ошибка", QString::fromStdString(err));
        return;
    }
    m_original = img;
    m_current = img;
    m_undo.clear();
    m_redo.clear();
    showImage();
    updateUi();
}

void MainWindow::saveFile() {
    if (m_current.empty())
        return;
    QString path = QFileDialog::getSaveFileName(this, "Сохранить BMP", "result.bmp", "BMP (*.bmp)");
    if (path.isEmpty())
        return;
    std::string err;
    if (!saveBmp(path.toStdString(), m_current, err))
        QMessageBox::warning(this, "Ошибка", QString::fromStdString(err));
}

void MainWindow::apply(const Image& result) {
    m_undo.push_back(m_current);
    if (m_undo.size() > size_t(kMaxHistory))
        m_undo.erase(m_undo.begin());
    m_redo.clear();
    m_current = result;
    showImage();
    updateUi();
}

void MainWindow::applyGray() {
    if (m_current.empty()) return;
    apply(filterGray(m_current));
}

void MainWindow::applyNegative() {
    if (m_current.empty()) return;
    apply(filterNegative(m_current));
}

void MainWindow::applyBlur() {
    if (m_current.empty()) return;
    Image r = m_current;
    for (int i = 0; i < strength(); ++i)
        r = filterBlur(r);
    apply(r);
}

void MainWindow::applySharpen() {
    if (m_current.empty()) return;
    Image r = m_current;
    for (int i = 0; i < strength(); ++i)
        r = filterSharpen(r);
    apply(r);
}

void MainWindow::applySepia() {
    if (m_current.empty()) return;
    apply(filterSepia(m_current));
}

void MainWindow::applyEdges() {
    if (m_current.empty()) return;
    apply(filterEdges(m_current));
}

void MainWindow::applyBrightness() {
    if (m_current.empty()) return;
    int percent = 0;
    if (auto* s = findChild<QSlider*>("sldBrightness"))
        percent = s->value();
    bool keepBlack = true;
    if (auto* c = findChild<QCheckBox*>("chkKeepBlack"))
        keepBlack = c->isChecked();
    apply(filterBrightness(m_current, percent, keepBlack));
}

void MainWindow::undo() {
    if (m_undo.empty()) return;
    m_redo.push_back(m_current);
    m_current = m_undo.back();
    m_undo.pop_back();
    showImage();
    updateUi();
}

void MainWindow::redo() {
    if (m_redo.empty()) return;
    m_undo.push_back(m_current);
    m_current = m_redo.back();
    m_redo.pop_back();
    showImage();
    updateUi();
}

void MainWindow::resetImage() {
    if (m_original.empty()) return;
    apply(m_original);
}

void MainWindow::showImage() {
    auto* lbl = findChild<QLabel*>("lblImage");
    if (!lbl || m_current.empty())
        return;

    QImage qi(m_current.rgb.data(), m_current.width, m_current.height,
              m_current.width * 3, QImage::Format_RGB888);
    lbl->setPixmap(QPixmap::fromImage(qi.copy()));
}

void MainWindow::updateUi() {
    bool has = !m_current.empty();
    for (const char* n : {"btnSave", "btnGray", "btnNegative", "btnBlur", "btnSharpen",
                          "btnSepia", "btnEdges", "btnApplyBrightness", "btnReset",
                          "sldBrightness", "chkKeepBlack", "spinStrength"})
        setEnabledByName(n, has);
    setEnabledByName("btnUndo", !m_undo.empty());
    setEnabledByName("btnRedo", !m_redo.empty());

    if (auto* info = findChild<QLabel*>("lblInfo")) {
        if (has)
            info->setText(QString("%1 × %2, шагов в истории: %3")
                              .arg(m_current.width).arg(m_current.height).arg(m_undo.size()));
        else
            info->setText("Файл не открыт");
    }
}
