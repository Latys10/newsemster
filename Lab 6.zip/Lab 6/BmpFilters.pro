QT += core gui widgets

CONFIG += c++17

TARGET = BmpFilters
TEMPLATE = app

SOURCES += \
    main.cpp \
    mainwindow.cpp \
    bmp.cpp \
    filters.cpp

HEADERS += \
    mainwindow.h \
    bmp.h \
    filters.h

FORMS += \
    mainwindow.ui
